plugins { id("com.android.application") }
android {
    namespace = "dev.orientforce"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.orientforce"
        minSdk = 30
        targetSdk = 34
        versionCode = 6
        versionName = "0.6"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    compileOnly(project(":xposed-stub"))
}
