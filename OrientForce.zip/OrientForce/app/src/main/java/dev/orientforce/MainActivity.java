package dev.orientforce;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    static final String[] LABELS = {
            "Авто: любое направление (4 стороны)",
            "Портрет",
            "Ландшафт",
            "Ландшафт, оба направления",
            "Портрет, оба направления",
            "Обратный ландшафт",
            "Обратный портрет",
            "Не трогать (как в системе)"};
    static final int[] VALUES = {10, 1, 0, 6, 7, 8, 9, -100};
    static final int NONE_INDEX = 7;

    static final String[] FIT_LABELS = {
            "Как есть",
            "Заполнить экран (обрезка по краям, как в плеерах)",
            "Растянуть на весь экран",
            "По центру (только выровнять, без масштаба)",
            "Компромисс: увеличить наполовину до заполнения",
            "Вручную (ползунки ниже)"};
    static final String[] FIT_SHORT = {
            "", "видео: заполнить", "видео: растянуть", "видео: по центру", "видео: компромисс", "видео: вручную"};

    static class Row {
        String pkg;
        String label;
        Drawable icon;
    }

    SharedPreferences sp;
    final List<Row> all = new ArrayList<>();
    final List<Row> shown = new ArrayList<>();
    BaseAdapter adapter;
    EditText search;

    int dp(int v) {
        return (int) (getResources().getDisplayMetrics().density * v);
    }

    boolean configured(String pkg) {
        return sp.contains(pkg) || sp.contains(Hook.FIT_PREFIX + pkg);
    }

    int fitIndex(String pkg) {
        int f = sp.getInt(Hook.FIT_PREFIX + pkg, 0);
        return (f >= 0 && f < FIT_LABELS.length) ? f : 0;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            sp = getSharedPreferences(Hook.PREFS, MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            sp = getSharedPreferences(Hook.PREFS, MODE_PRIVATE);
            Toast.makeText(this, "Модуль не активирован в LSPosed: настройки не дойдут до системы",
                    Toast.LENGTH_LONG).show();
        }

        FrameLayout frame = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setImageResource(R.drawable.bg);
        frame.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        CheckBox dbg = new CheckBox(this);
        dbg.setText("Диагностика: показывать тосты в приложениях");
        dbg.setChecked(sp.getBoolean("debug", true));
        dbg.setOnCheckedChangeListener((cbv, on) -> sp.edit().putBoolean("debug", on).apply());
        root.addView(dbg);
        search = new EditText(this);
        search.setHint("Поиск приложения");
        search.setHintTextColor(0x99FFFFFF);
        search.setSingleLine(true);
        root.addView(search, new LinearLayout.LayoutParams(-1, -2));
        ListView list = new ListView(this);
        list.setCacheColorHint(0);
        list.setDivider(new ColorDrawable(0x22FFFFFF));
        list.setDividerHeight(1);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        adapter = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View v, ViewGroup parent) {
                if (v == null) v = makeRow();
                Row r = shown.get(i);
                LinearLayout row = (LinearLayout) v;
                ((ImageView) row.getChildAt(0)).setImageDrawable(r.icon);
                LinearLayout col = (LinearLayout) row.getChildAt(1);
                ((TextView) col.getChildAt(0)).setText(r.label);
                int mi = modeIndex(r.pkg);
                String sub = LABELS[mi];
                if (mi != NONE_INDEX && sp.getBoolean(Hook.RELAUNCH_PREFIX + r.pkg, true)) {
                    sub = sub + "  ↻";
                }
                int fi = fitIndex(r.pkg);
                if (fi != 0) sub = sub + "  •  " + FIT_SHORT[fi];
                if (fi == 5) {
                    sub = sub + " ×" + (sp.getInt(Hook.ZX_PREFIX + r.pkg, 10) / 10f)
                            + "/" + (sp.getInt(Hook.ZY_PREFIX + r.pkg, 10) / 10f);
                }
                ((TextView) col.getChildAt(1)).setText(r.pkg + "\n" + sub);
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> pick(shown.get(pos)));

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            public void onTextChanged(CharSequence s, int a, int c, int d) {}
            public void afterTextChanged(Editable e) { filter(); }
        });

        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent it = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            Set<String> seen = new HashSet<>();
            List<Row> tmp = new ArrayList<>();
            for (ResolveInfo ri : pm.queryIntentActivities(it, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (!seen.add(pkg)) continue;
                Row r = new Row();
                r.pkg = pkg;
                r.label = String.valueOf(ri.loadLabel(pm));
                r.icon = ri.loadIcon(pm);
                tmp.add(r);
            }
            runOnUiThread(() -> { all.clear(); all.addAll(tmp); filter(); });
        }).start();
    }

    View makeRow() {
        int d = dp(8);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(d * 2, d, d * 2, d);
        ImageView icon = new ImageView(this);
        row.addView(icon, new LinearLayout.LayoutParams(d * 5, d * 5));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(d * 2, 0, 0, 0);
        TextView t1 = new TextView(this);
        t1.setTextSize(16);
        TextView t2 = new TextView(this);
        t2.setTextSize(12);
        t2.setAlpha(0.7f);
        col.addView(t1);
        col.addView(t2);
        row.addView(col);
        return row;
    }

    int modeIndex(String pkg) {
        if (!sp.contains(pkg)) return NONE_INDEX;
        int v = sp.getInt(pkg, -100);
        for (int i = 0; i < VALUES.length; i++) if (VALUES[i] == v) return i;
        return NONE_INDEX;
    }

    void filter() {
        String q = search.getText().toString().toLowerCase(Locale.ROOT).trim();
        shown.clear();
        for (Row r : all) {
            if (q.isEmpty() || r.label.toLowerCase(Locale.ROOT).contains(q)
                    || r.pkg.toLowerCase(Locale.ROOT).contains(q)) shown.add(r);
        }
        Collections.sort(shown, (x, y) -> {
            boolean cx = configured(x.pkg), cy = configured(y.pkg);
            if (cx != cy) return cx ? -1 : 1;
            return x.label.compareToIgnoreCase(y.label);
        });
        adapter.notifyDataSetChanged();
    }

    SeekBar seek(int tenths) {
        SeekBar s = new SeekBar(this);
        s.setMax(50);
        s.setProgress(Math.max(0, Math.min(50, tenths - 10)));
        return s;
    }

    TextView header(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setAlpha(0.7f);
        t.setPadding(0, dp(14), 0, dp(4));
        return t;
    }

    void pick(final Row r) {
        int pad = dp(16);
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad / 2, pad, 0);

        box.addView(header("Ориентация"));
        final RadioGroup rg = new RadioGroup(this);
        for (int i = 0; i < LABELS.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(LABELS[i]);
            rb.setId(100 + i);
            rg.addView(rb);
        }
        rg.check(100 + modeIndex(r.pkg));
        box.addView(rg);

        final CheckBox cb = new CheckBox(this);
        cb.setText("Пересоздавать окно при повороте (лечит кривую вёрстку и обрезку)");
        cb.setChecked(sp.getBoolean(Hook.RELAUNCH_PREFIX + r.pkg, true));
        box.addView(cb);

        box.addView(header("Видео (нужно добавить приложение в область действия модуля в Vector)"));
        final RadioGroup fg = new RadioGroup(this);
        for (int i = 0; i < FIT_LABELS.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(FIT_LABELS[i]);
            rb.setId(200 + i);
            fg.addView(rb);
        }
        fg.check(200 + fitIndex(r.pkg));
        box.addView(fg);

        box.addView(header("Ручной масштаб видео (для режима «Вручную»)"));
        final TextView zl = new TextView(this);
        final SeekBar zx = seek(sp.getInt(Hook.ZX_PREFIX + r.pkg, 10));
        final SeekBar zy = seek(sp.getInt(Hook.ZY_PREFIX + r.pkg, 10));
        final Runnable upd = () -> zl.setText("Ширина ×" + (10 + zx.getProgress()) / 10f
                + "     Высота ×" + (10 + zy.getProgress()) / 10f);
        SeekBar.OnSeekBarChangeListener sl = new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int pr, boolean user) { upd.run(); }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        };
        zx.setOnSeekBarChangeListener(sl);
        zy.setOnSeekBarChangeListener(sl);
        upd.run();
        box.addView(zl);
        box.addView(zx);
        box.addView(zy);

        sv.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(r.label)
                .setView(sv)
                .setPositiveButton("Сохранить", (dlg, w) -> {
                    int idx = rg.getCheckedRadioButtonId() - 100;
                    if (idx < 0 || idx >= VALUES.length) idx = NONE_INDEX;
                    int fi = fg.getCheckedRadioButtonId() - 200;
                    if (fi < 0 || fi >= FIT_LABELS.length) fi = 0;
                    SharedPreferences.Editor e = sp.edit();
                    if (VALUES[idx] == -100) {
                        e.remove(r.pkg);
                        e.remove(Hook.RELAUNCH_PREFIX + r.pkg);
                    } else {
                        e.putInt(r.pkg, VALUES[idx]);
                        e.putBoolean(Hook.RELAUNCH_PREFIX + r.pkg, cb.isChecked());
                    }
                    if (fi == 0) e.remove(Hook.FIT_PREFIX + r.pkg);
                    else e.putInt(Hook.FIT_PREFIX + r.pkg, fi);
                    if (fi == 5) {
                        e.putInt(Hook.ZX_PREFIX + r.pkg, 10 + zx.getProgress());
                        e.putInt(Hook.ZY_PREFIX + r.pkg, 10 + zy.getProgress());
                    }
                    e.apply();
                    Toast.makeText(this, "Перезапусти приложение, чтобы применилось",
                            Toast.LENGTH_SHORT).show();
                    filter();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }
}
