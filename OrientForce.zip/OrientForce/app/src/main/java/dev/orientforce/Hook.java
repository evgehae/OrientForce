package dev.orientforce;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Toast;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public class Hook implements IXposedHookLoadPackage {
    static final String MY_PKG = "dev.orientforce";
    static final String PREFS = "cfg";
    static final String TAG = "OrientForce: ";
    static final String RELAUNCH_PREFIX = "r:";
    static final String FIT_PREFIX = "f:";
    static final String ZX_PREFIX = "zx:";
    static final String ZY_PREFIX = "zy:";

    // Config changes that the activity must NOT handle itself while we force an orientation:
    // the system then recreates the window on rotation, so the layout is rebuilt cleanly.
    static final int RELAUNCH_MASK = ActivityInfo.CONFIG_ORIENTATION
            | ActivityInfo.CONFIG_SCREEN_SIZE
            | ActivityInfo.CONFIG_SMALLEST_SCREEN_SIZE
            | ActivityInfo.CONFIG_SCREEN_LAYOUT;

    static Class<?> arClass;
    static XSharedPreferences prefs;
    static long lastCheck;
    static volatile Map<String, Integer> cache = new HashMap<>();
    static volatile Map<String, Boolean> relaunch = new HashMap<>();
    static volatile Map<String, Integer> fit = new HashMap<>();
    static volatile Map<String, Integer> zoomX = new HashMap<>();
    static volatile Map<String, Integer> zoomY = new HashMap<>();
    static volatile boolean debug = true;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if ("android".equals(lp.packageName)) {
            hookSystem(lp);
            return;
        }
        if (MY_PKG.equals(lp.packageName)) return;
        if (!lp.isFirstApplication) return;
        hookApp(lp.packageName);
    }

    // ---------------------------------------------------------------- system_server

    static void hookSystem(XC_LoadPackage.LoadPackageParam lp) {
        try {
            arClass = Class.forName("com.android.server.wm.ActivityRecord", false, lp.classLoader);
            hookOne("getOverrideOrientation", 0);
            hookOne("getOrientation", 1);
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
        try {
            Method m = ActivityInfo.class.getDeclaredMethod("getRealConfigChanged");
            XposedBridge.hookMethod(m, CFG_HOOK);
            XposedBridge.log(TAG + "hooked ActivityInfo#getRealConfigChanged");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "getRealConfigChanged hook failed: " + t);
        }
    }

    static void hookOne(String name, int params) {
        for (Class<?> c = arClass; c != null; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().equals(name) && m.getParameterCount() == params
                        && m.getReturnType() == int.class) {
                    XposedBridge.hookMethod(m, HOOK);
                    XposedBridge.log(TAG + "hooked " + c.getName() + "#" + name);
                    return;
                }
            }
        }
        XposedBridge.log(TAG + "NOT FOUND " + name);
    }

    static final XC_MethodHook HOOK = new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            try {
                if (arClass == null || !arClass.isInstance(p.thisObject)) return;
                Object r = p.getResult();
                if (!(r instanceof Integer)) return;
                int v = (Integer) r;
                if (v == -2 || v == -3) return; // UNSET / BEHIND: activity gives no opinion
                String pkg = (String) XposedHelpers.getObjectField(p.thisObject, "packageName");
                Integer o = lookup(pkg);
                if (o != null) p.setResult(o);
            } catch (Throwable ignored) {
            }
        }
    };

    static final XC_MethodHook CFG_HOOK = new XC_MethodHook() {
        @Override
        protected void afterHookedMethod(MethodHookParam p) {
            try {
                Object r = p.getResult();
                if (!(r instanceof Integer)) return;
                ActivityInfo ai = (ActivityInfo) p.thisObject;
                String pkg = ai.packageName;
                if (pkg == null || lookup(pkg) == null) return;
                Boolean rl = relaunch.get(pkg);
                if (rl != null && !rl) return;
                int cleaned = ((Integer) r) & ~RELAUNCH_MASK;
                p.setResult(cleaned);
            } catch (Throwable ignored) {
            }
        }
    };

    // ---------------------------------------------------------------- app process (video fit)
    // fit modes: 0 off, 1 fill (cover, crop), 2 stretch, 3 center only, 4 half-way to fill, 5 manual

    static final Set<Activity> seen =
            Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap<Activity, Boolean>()));
    static final Set<String> alive = Collections.synchronizedSet(new HashSet<String>());
    // wanted layer scale for SurfaceViews: [kx, ky, nudge]
    static final Map<Object, float[]> want =
            Collections.synchronizedMap(new WeakHashMap<Object, float[]>());
    static String lastLog = "";
    static long lastToast;
    static boolean surfHooked;

    static void toast(final Activity a, final String msg) {
        long now = SystemClock.uptimeMillis();
        if (now - lastToast < 2500) return;
        lastToast = now;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Toast.makeText(a, msg, Toast.LENGTH_LONG).show();
                } catch (Throwable ignored) {
                }
            }
        });
    }

    // SurfaceView layers are positioned by SurfaceView itself; scaling the View alone does not move
    // the layer on every device. So the final rectangle is enlarged right before it is applied.
    static final XC_MethodHook SURF_HOOK = new XC_MethodHook() {
        @Override
        protected void beforeHookedMethod(MethodHookParam p) {
            try {
                float[] w = want.get(p.thisObject);
                if (w == null || p.args == null) return;
                if (Math.abs(w[0] - 1f) < 0.005f && Math.abs(w[1] - 1f) < 0.005f) return;
                for (int i = 0; i < p.args.length; i++) {
                    if (p.args[i] instanceof Rect) {
                        Rect r = (Rect) p.args[i];
                        int cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
                        int hw = Math.round(r.width() * w[0] / 2f);
                        int hh = Math.round(r.height() * w[1] / 2f);
                        p.args[i] = new Rect(cx - hw, cy - hh, cx + hw, cy + hh);
                        return;
                    }
                }
            } catch (Throwable ignored) {
            }
        }
    };

    static void hookSurface() {
        if (surfHooked) return;
        surfHooked = true;
        int n = 0;
        try {
            for (Method m : SurfaceView.class.getDeclaredMethods()) {
                String nm = m.getName();
                if (nm.equals("applySurfaceTransforms")) {
                    XposedBridge.hookMethod(m, SURF_HOOK);
                    XposedBridge.log(TAG + "hooked SurfaceView#" + nm);
                    n++;
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "surface hook failed: " + t);
        }
        if (n == 0) XposedBridge.log(TAG + "SurfaceView#applySurfaceTransforms NOT FOUND");
    }

    static void hookApp(final String pkg) {
        hookSurface();
        try {
            Method m = Activity.class.getDeclaredMethod("onResume");
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Activity a = (Activity) p.thisObject;
                        int fm = fitMode(pkg);
                        if (seen.add(a)) {
                            a.getWindow().getDecorView().getViewTreeObserver()
                                    .addOnPreDrawListener(new FitListener(a, pkg));
                        }
                        if (debug && alive.add(pkg)) {
                            String msg = "OF жив: " + pkg + ", видео=" + fm
                                    + ", настроек " + cache.size() + "/" + fit.size();
                            XposedBridge.log(TAG + msg);
                            toast(a, msg);
                        }
                    } catch (Throwable t) {
                        XposedBridge.log(t);
                    }
                }
            });
            XposedBridge.log(TAG + "video-fit hook ready in " + pkg);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "video-fit hook failed: " + t);
        }
    }

    static class FitListener implements ViewTreeObserver.OnPreDrawListener {
        final WeakReference<Activity> ref;
        final String pkg;
        long last;
        int lastLand = -1;

        FitListener(Activity a, String pkg) {
            this.ref = new WeakReference<>(a);
            this.pkg = pkg;
        }

        @Override
        public boolean onPreDraw() {
            long now = SystemClock.uptimeMillis();
            if (now - last < 150) return true;
            last = now;
            try {
                Activity a = ref.get();
                if (a == null) return true;
                int mode = fitMode(pkg);
                if (mode == 0) return true;
                View decor = a.getWindow().getDecorView();
                int rw = decor.getWidth(), rh = decor.getHeight();
                if (rw <= 0 || rh <= 0) return true;
                int land = rw > rh ? 1 : 0;
                if (lastLand != -1 && lastLand != land) decor.requestLayout();
                lastLand = land;

                StringBuilder sum = new StringBuilder();
                int n = walk(decor, rw, rh, mode, pkg, sum);
                String s;
                if (n == 0) {
                    StringBuilder sb = new StringBuilder("OF нет вью: ");
                    describe(decor, sb, new int[]{4});
                    s = sb.toString();
                } else {
                    s = "OF м" + mode + " " + sum;
                }
                if (!s.equals(lastLog)) {
                    lastLog = s;
                    XposedBridge.log(TAG + s + " | окно " + rw + "x" + rh);
                    if (debug) toast(a, s);
                }
            } catch (Throwable ignored) {
            }
            return true;
        }
    }

    static int walk(View v, int rw, int rh, int mode, String pkg, StringBuilder sum) {
        if (v instanceof TextureView || v instanceof SurfaceView) {
            return fitOne(v, rw, rh, mode, pkg, sum) ? 1 : 0;
        }
        int n = 0;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                n += walk(g.getChildAt(i), rw, rh, mode, pkg, sum);
            }
        }
        return n;
    }

    static String sn(View v) {
        String n = v.getClass().getSimpleName();
        if (n.length() > 10) n = n.substring(0, 10);
        return (v instanceof TextureView ? "T " : "S ") + n;
    }

    static void describe(View v, StringBuilder sb, int[] left) {
        if (left[0] <= 0 || !v.isShown()) return;
        int w = v.getWidth(), h = v.getHeight();
        if (v instanceof TextureView || v instanceof SurfaceView) {
            sb.append(sn(v)).append(' ').append(w).append('x').append(h).append("; ");
            left[0]--;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) describe(g.getChildAt(i), sb, left);
        }
    }

    static String r2(float x) {
        return String.valueOf(Math.round(x * 100) / 100f);
    }

    static float zoom(Map<String, Integer> mp, String pkg) {
        Integer t = mp.get(pkg);
        float f = (t == null ? 10 : t) / 10f;
        return Math.max(1f, Math.min(f, 8f));
    }

    static boolean fitOne(View v, int rw, int rh, int mode, String pkg, StringBuilder sum) {
        int vw = v.getWidth(), vh = v.getHeight();
        if (vw <= 0 || vh <= 0 || !v.isShown()) return false;
        if ((long) vw * vh * 25 < (long) rw * rh) return false; // ignore surfaces under 4% of the window

        // If the app letterboxes inside a TextureView with its own matrix, take that into account.
        float mx = 1f, my = 1f;
        if (v instanceof TextureView) {
            try {
                Matrix m = new Matrix();
                ((TextureView) v).getTransform(m);
                float[] f = new float[9];
                m.getValues(f);
                if (f[Matrix.MSCALE_X] > 0.05f) mx = f[Matrix.MSCALE_X];
                if (f[Matrix.MSCALE_Y] > 0.05f) my = f[Matrix.MSCALE_Y];
            } catch (Throwable ignored) {
            }
        }
        float evw = vw * mx, evh = vh * my; // effective size of the picture
        float sx = 1f, sy = 1f;
        if (mode == 1 || mode == 4) {
            float s = Math.max(rw / evw, rh / evh);
            if (s < 1f) s = 1f;
            if (mode == 4) s = 1f + (s - 1f) * 0.5f;
            sx = s;
            sy = s;
        } else if (mode == 2) {
            sx = Math.max(1f, rw / evw);
            sy = Math.max(1f, rh / evh);
        } else if (mode == 5) {
            sx = zoom(zoomX, pkg);
            sy = zoom(zoomY, pkg);
        }

        v.setPivotX(vw / 2f);
        v.setPivotY(vh / 2f);
        if (v instanceof SurfaceView) {
            // layer-level scaling (see SURF_HOOK); keep the View itself unscaled
            v.setScaleX(1f);
            v.setScaleY(1f);
            float[] cur = want.get(v);
            if (cur == null) {
                cur = new float[]{1f, 1f, 0f};
                want.put(v, cur);
            }
            if (Math.abs(cur[0] - sx) > 0.005f || Math.abs(cur[1] - sy) > 0.005f) {
                cur[0] = sx;
                cur[1] = sy;
                float nn = cur[2] == 0f ? 1f : 0f; // 1px nudge forces the surface position update
                v.setTranslationY(v.getTranslationY() + (nn - cur[2]));
                cur[2] = nn;
            }
        } else {
            v.setScaleX(sx);
            v.setScaleY(sy);
        }

        // Horizontal centering of the picture in the window (fixes the "shifted to the side" case).
        int[] loc = new int[2];
        v.getLocationInWindow(loc);
        float baseCx = loc[0] - v.getTranslationX() + vw * v.getScaleX() / 2f;
        float tx = rw / 2f - baseCx;
        if (Math.abs(tx) < 2f || Math.abs(tx) > rw * 0.35f) tx = 0f;
        v.setTranslationX(tx);

        if (sum.length() < 70) {
            if (sum.length() > 0) sum.append("; ");
            sum.append(sn(v)).append(' ').append(vw).append('x').append(vh)
                    .append(" ×").append(r2(sx));
            if (Math.abs(sx - sy) > 0.01f) sum.append('/').append(r2(sy));
        }
        return true;
    }

    // ---------------------------------------------------------------- config

    static synchronized void refresh() {
        long now = SystemClock.uptimeMillis();
        if (now - lastCheck <= 1000) return;
        lastCheck = now;
        try {
            if (prefs == null) {
                prefs = new XSharedPreferences(MY_PKG, PREFS);
                prefs.makeWorldReadable();
                rebuild();
            } else if (prefs.hasFileChanged()) {
                prefs.reload();
                rebuild();
            }
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }

    static Integer lookup(String pkg) {
        refresh();
        return pkg == null ? null : cache.get(pkg);
    }

    static int fitMode(String pkg) {
        refresh();
        Integer f = fit.get(pkg);
        return f == null ? 0 : f;
    }

    static void rebuild() {
        Map<String, Integer> m = new HashMap<>();
        Map<String, Boolean> rl = new HashMap<>();
        Map<String, Integer> ft = new HashMap<>();
        Map<String, Integer> zx = new HashMap<>();
        Map<String, Integer> zy = new HashMap<>();
        Map<String, ?> all = prefs.getAll();
        if (all != null) {
            for (Map.Entry<String, ?> e : all.entrySet()) {
                Object v = e.getValue();
                String k = e.getKey();
                if (v instanceof Integer && k.startsWith(FIT_PREFIX)) {
                    ft.put(k.substring(FIT_PREFIX.length()), (Integer) v);
                } else if (v instanceof Integer && k.startsWith(ZX_PREFIX)) {
                    zx.put(k.substring(ZX_PREFIX.length()), (Integer) v);
                } else if (v instanceof Integer && k.startsWith(ZY_PREFIX)) {
                    zy.put(k.substring(ZY_PREFIX.length()), (Integer) v);
                } else if (v instanceof Integer) {
                    m.put(k, (Integer) v);
                } else if (v instanceof Boolean && k.startsWith(RELAUNCH_PREFIX)) {
                    rl.put(k.substring(RELAUNCH_PREFIX.length()), (Boolean) v);
                }
            }
        }
        Object dv = (all == null) ? null : all.get("debug");
        debug = (dv instanceof Boolean) ? (Boolean) dv : true;
        cache = m;
        relaunch = rl;
        fit = ft;
        zoomX = zx;
        zoomY = zy;
        XposedBridge.log(TAG + "config loaded, orient=" + m.size() + " fit=" + ft.size());
    }
}
