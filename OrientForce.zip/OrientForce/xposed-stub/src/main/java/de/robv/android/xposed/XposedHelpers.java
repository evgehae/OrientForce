package de.robv.android.xposed;
public final class XposedHelpers {
    public static Object getObjectField(Object obj, String fieldName) { return null; }
}
