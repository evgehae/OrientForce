package de.robv.android.xposed;
import java.util.Map;
public class XSharedPreferences {
    public XSharedPreferences(String packageName, String prefFileName) {}
    public boolean makeWorldReadable() { return false; }
    public void reload() {}
    public boolean hasFileChanged() { return false; }
    public Map<String, ?> getAll() { return null; }
}
